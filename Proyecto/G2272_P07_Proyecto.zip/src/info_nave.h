#ifndef SRC_INFO_NAVE_H_
#define SRC_INFO_NAVE_H_

#include <types.h>


info_nave * info_nave_create(int equipo, int num);
void info_nave_destroy(info_nave * info);



#endif