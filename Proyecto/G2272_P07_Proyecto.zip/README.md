# Proyecto de Sistemas Operativos

## Compilacion
Compilar mediante `make`, `make -B` o `make all`.

## Ejecución:
### style_test 
Ejectutar mediante el comando: `$ ./bin/style_test`. 

### launcher (simulador) 
Ejecutar mediante el comando `$ ./bin/launcher -c -f <fichero>`. Las flags son opcionales. Para ayuda de ejecución, emplear `-h`.

### monitor 
Ejecutar mediante el comando `$ ./bin/monitor`